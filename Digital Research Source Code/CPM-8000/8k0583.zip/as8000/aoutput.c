#include "stdio.h"
/*
 * Changed to use the Standard I/O library  9/13/82  FZ
 */
#include "acom.h"

static	char	ident[] = "@(#)a.output.c	3.1";
